﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ButtonVerg
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        List<string> addons = new List<string>();
        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            foreach(string f in Directory.GetDirectories(@"D:\Azubiprojekte\Test"))
            {
                addons.Add(f.Split('\\')[f.Split('\\').Count()-1]);
            }
            progressBar1.Value = 0;
            progressBar1.Maximum = addons.Count - 1;
            for(int i=0; i< addons.Count-1;i++)
            {
                progressBar1.Value++;
                double result = stringcompare.Compare(addons[i], addons[i + 1]);
                if(result>0.5)
                {
                    textBox1.Text += addons[i] + " & " + addons[i + 1];
                }
            }
        }

      
    }
}
